JOHN FF para Android — projeto-fonte
=====================================
Este é o código-fonte do aplicativo, não um APK pronto.
Abra a pasta no Android Studio e gere o APK em Build > Build Bundle(s) / APK(s) > Build APK(s).
O app mostra https://john2244.pythonanywhere.com/ em uma WebView e abre o convite Discord no navegador/app externo.
Precisa de internet. O usuário e senha continuam no servidor PythonAnywhere, não estão no APK.
O primeiro login de cada usuário fica vinculado ao armazenamento da WebView deste app;
se a mesma pessoa já usou outro navegador, o administrador precisa liberar o vínculo.
O app não lê IMEI. Distribuir o APK exige assinatura e testes num aparelho real.
